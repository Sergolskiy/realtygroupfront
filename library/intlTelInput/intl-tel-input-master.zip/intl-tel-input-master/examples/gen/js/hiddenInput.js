var input = document.querySelector("#phone");
window.intlTelInput(input, {
  hiddenInput: "full_phone",
  utilsScript: "../../build/js/utils.js?1541153396801" // just for formatting/placeholders etc
});
